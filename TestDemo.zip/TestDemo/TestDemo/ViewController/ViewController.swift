//
//  ViewController.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var newsTableView: UITableView!
    
    let viewModel = NewsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        newsTableView.estimatedRowHeight = CGFloat(150)
        
        // Async api call throw actor
        Task { @MainActor in
            do{
                self.loadinHubShow()
                try await viewModel.fetchQuakes()
                newsTableView.reloadData()
                loadinHubDismiss()
            } catch {
                //handle the error
                loadinHubDismiss()
                print("Api called failed!!!")
            }
        }
    }
    
    // MARK: Navigation
    private func navigateToDetail(article: NewsHeadline) {
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc: NewsDetailViewController = storyboard.instantiateViewController(withIdentifier: "NewsDetailViewController") as? NewsDetailViewController else { return }
        vc.viewModel = NewsDetailViewModel(article: article)
        self.present(vc, animated: true, completion: nil)
    }
}

// MARK: tableview datasourse
extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.articleList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell", for: indexPath) as? NewsCell 
        else { return UITableViewCell() }
        
        cell.setData(data: viewModel.articleList[indexPath.row])
        
        return cell
    }
    
    func tableView(_: UITableView, heightForRowAt _: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: tableview delegate
extension ViewController: UITableViewDelegate {
    func tableView(_: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.navigateToDetail(article: self.viewModel.articleList[indexPath.row])
    }
}

// MARK: Custom loader
extension ViewController {
    private func loadinHubShow() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.large
        loadingIndicator.startAnimating();
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    private func loadinHubDismiss() {
        dismiss(animated: false, completion: nil)
    }
}
