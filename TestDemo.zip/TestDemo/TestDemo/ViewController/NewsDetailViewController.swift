//
//  NewsDetailViewController.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import UIKit

class NewsDetailViewController: UIViewController {

    @IBOutlet weak var headlineLabel: UILabel!
    @IBOutlet weak var newsDetailLabel: UILabel!
    @IBOutlet weak var newsImage: LazyImageView!
    
    var viewModel: NewsDetailViewModel? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.setUpData()
    }
    
    // MARK: - Navigation
    @IBAction func backButtonAction(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    // MARK: - Setup data
    private func setUpData() {
        guard let viewModel else { return}
        headlineLabel.text = viewModel.article.author
        newsDetailLabel.text = viewModel.article.source.name + "\n \n" + viewModel.article.content
        guard let imageUrl = URL(string: viewModel.article.urlToImage) else {
            return
        }
        newsImage.loadImage(fromURL: imageUrl)
    }

}
