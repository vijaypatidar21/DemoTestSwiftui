//
//  NewsCell.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import UIKit

class NewsCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLable: UILabel!
    @IBOutlet weak var newsImageView: LazyImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setData(data: NewsHeadline) {
        titleLabel.text = data.title
        detailLable.text = data.description
        guard let imageUrl = URL(string: data.urlToImage) else {
            return
        }
        newsImageView.loadImage(fromURL: imageUrl)
    }
}
