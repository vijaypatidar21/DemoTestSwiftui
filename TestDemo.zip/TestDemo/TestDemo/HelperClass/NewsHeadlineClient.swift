//
//  NewsHeadlineClient.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import Foundation
import UIKit

class NewsHeadlineClient {
    
    static let shared = NewsHeadlineClient()
    static private let apiKey = "5eb27460115c4302a3b762b81188e686"
    
    func fetchLatestNews() async throws -> NewsArticleResult {
        
        let url = URL(string: "https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=\(NewsHeadlineClient.apiKey)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")
        
        let request = URLRequest(url: url!)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        let fetchedData = try JSONDecoder().decode(NewsArticleResult.self, from: try mapResponse(response: (data,response)))
        
        return fetchedData
    }
    
    func mapResponse(response: (data: Data, response: URLResponse)) throws -> Data {
        guard let httpResponse = response.response as? HTTPURLResponse else {
            return response.data
        }
        switch httpResponse.statusCode {
        case 200..<300:
            let string = String(data: response.data, encoding: .utf8)!
            print(string)
            return response.data
        default:
            throw NetworkError.invalidRequestResponse
        }
    }
    
    public enum NetworkError: Error, LocalizedError {
        case invalidRequestResponse
    }
}
