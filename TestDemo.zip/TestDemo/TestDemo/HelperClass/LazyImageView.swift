//
//  LazyImageView.swift
//  TestDemo
//
//  Created by vpatidar on 15/10/23.
//

import Foundation
import UIKit

class LazyImageView: UIImageView {
    
    private let imageCache = NSCache<AnyObject, UIImage>()
    
    func loadImage(fromURL imageUrl: URL) {
        if let cacheImage = self.imageCache.object(forKey: imageUrl as AnyObject) {
            self.image = cacheImage
            return
        }
        DispatchQueue.global().async { [weak self] in
            guard let imageData = try? Data(contentsOf: imageUrl) else { return }
            guard let image = UIImage(data: imageData) else { return }
            DispatchQueue.main.async {
                self?.imageCache.setObject(image, forKey: imageUrl as AnyObject)
                self?.image = image
            }
        }
    }
    
}
