//
//  NewsViewModel.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import Foundation

class NewsViewModel : NSObject {
    
    var articleList: [NewsHeadline] = []
    
    override init() {
        super.init()
    }
    
    // Async api call fucntion
    func fetchQuakes() async throws {
        let latestNews = try await NewsHeadlineClient.shared.fetchLatestNews()
        self.articleList = latestNews.articles
    }

}



