//
//  NewsDetailViewModel.swift
//  TestDemo
//
//  Created by vpatidar on 14/10/23.
//

import Foundation

class NewsDetailViewModel : NSObject {
    
    var article: NewsHeadline

    init(article: NewsHeadline) {
        self.article = article
    }

}
